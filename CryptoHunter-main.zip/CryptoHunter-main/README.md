# Crypto Hunter

   React Crypto Currency App
    
# Live Project Link
   
   Crypto Hunter: https://cryptohunter111.netlify.app/
   
# Introduction
This is a code repository for the corresponding Project.

In this project, I have build a Crypto Currency watch app. While building it, I learn many advanced React & JavaScript topics. Some of them are Google Firebase for Login and Authentication purposes, Chart JS for showing chart for showing regular frequency of currency, React Routers and Coin Gecko API. 

This app helps its user to watch over all the crypto currency prices, there last 24hr changes, its market cap and much more. In todays world everybody wants to invest in digital currency and this app helps them to choose where to invest.
   
# Preview

![Crypto Hunter (Homepage)](https://user-images.githubusercontent.com/76047915/163677963-20263405-0da2-432c-934f-1d7f802b4f1f.png)

![Crypto Hunter (Coin Page)](https://user-images.githubusercontent.com/76047915/163677977-996a699b-f7c1-461c-9e81-131fc0e2eabf.png)

![Crypto Hunter (Login Panel)](https://user-images.githubusercontent.com/76047915/163677990-041ec5a6-9589-416b-8c75-daa7058451f4.png)

## Setup:
- run ```npm i && npm start```

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can't go back!**

If you aren't satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you're on your own.

You don't have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn't feel obligated to use this feature. However we understand that this tool wouldn't be useful if you couldn't customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

### Code Splitting

This section has moved here: [https://facebook.github.io/create-react-app/docs/code-splitting](https://facebook.github.io/create-react-app/docs/code-splitting)

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This section has moved here: [https://facebook.github.io/create-react-app/docs/advanced-configuration](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

This section has moved here: [https://facebook.github.io/create-react-app/docs/deployment](https://facebook.github.io/create-react-app/docs/deployment)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)
