const firebaseConfig = {
  apiKey: "AIzaSyC_-D_A5gpVpjhWAmPm9h56m8RvdShUTzs",
  authDomain: "crypto-hunter-573c4.firebaseapp.com",
  projectId: "crypto-hunter-573c4",
  storageBucket: "crypto-hunter-573c4.appspot.com",
  messagingSenderId: "904224765530",
  appId: "1:904224765530:web:30c2fa19c7d98ffc140a63",
};

export default firebaseConfig;
